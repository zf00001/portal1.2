package com.oa.sys.dao;

import java.util.List;

import com.oa.sys.model.OaSysRole;

/**
 * Created by zf on 2023年2月2日.
 */
public interface OaSysRoleDao {

	int findCount();

	List<OaSysRole> findByPage(int begin, int pageSize);

	void save(OaSysRole oaSysRole);

	OaSysRole findById(String rid);

	void update(OaSysRole oaSysRole);

	List<OaSysRole> findAll();

}
