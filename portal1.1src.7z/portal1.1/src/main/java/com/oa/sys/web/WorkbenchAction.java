/*
 * $Id$
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.oa.sys.web;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.oa.sys.model.OaSysLog;
import com.oa.sys.model.OaSysUser;
import com.oa.sys.service.OaSysLogService;
import com.oa.sys.service.OaSysUserService;
import com.oa.sys.util.DataUtil;
import com.oa.sys.util.DateUtil;
import com.oa.sys.util.ImageUtil;
import com.oa.sys.util.LicenseUtil;
import com.oa.sys.util.MD5Util;
import com.oa.sys.util.UUIDUtil;
import com.oa.sys.util.ValidateUtil;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

/**
 * <code>DateAction</code>
 */
@Namespace("/oa/sys/workbench")
@Results({ @Result(name = "aboutUI", location = "about.jsp"), @Result(name = "imageSuccess", type = "stream", params = {
		"contentType", "image/jpeg", "inputName", "imageStream", "bufferSize", "2048" }) })
public class WorkbenchAction extends ActionSupport implements ModelDriven<OaSysUser> {

	private OaSysUser oaSysUser = new OaSysUser();

	public OaSysUser getOaSysUser() {
		return oaSysUser;
	}

	public void setOaSysUser(OaSysUser oaSysUser) {
		this.oaSysUser = oaSysUser;
	}

	@Override
	public OaSysUser getModel() {
		return oaSysUser;
	}

	@Autowired
	private OaSysUserService oaSysUserService;

	public OaSysUserService getOaSysUserService() {
		return oaSysUserService;
	}

	public void setOaSysUserService(OaSysUserService oaSysUserService) {
		this.oaSysUserService = oaSysUserService;
	}

	public String image() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();

		// 文件类型
		response.setContentType("image/jpeg");
		// 设置缓存
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expires", 0);

		ImageUtil imageUtil = new ImageUtil();
		BufferedImage image = imageUtil.getImage();

		request.getSession().setAttribute("textaimage", imageUtil.getText());

		try {
			// 获取流发送给前台
			ServletOutputStream outputStream = response.getOutputStream();
			ImageIO.write(image, "JPEG", outputStream);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		return "imageSuccess";
	}

	public String getCopyrightYear() {
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");

		PrintWriter pw = null;
		try {
			pw = response.getWriter();
			pw.write(LicenseUtil.getCopyrightYear());
			pw.flush();
			pw.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		return null;
	}

	public String aboutUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();

		OaSysUser oaSysUserFromdb = oaSysUserService.findBySys();
		if (oaSysUserFromdb != null) {
			String name = oaSysUserFromdb.getName();
			session.setAttribute("aboutUser", "本产品授权给:" + name);
		} else {
			session.setAttribute("aboutUser", null);
		}

		return "aboutUI";
	}

	public String license() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();

		// 文件类型
		response.setContentType("image/jpeg");
		// 设置缓存
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expires", 0);

		LicenseUtil licenseUtil = new LicenseUtil();
		BufferedImage image = licenseUtil.getImage();

		request.getSession().setAttribute("textabout", licenseUtil.getText());
		try {
			// 获取流发送给前台
			ServletOutputStream outputStream = response.getOutputStream();

			ImageIO.write(image, "JPEG", outputStream);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		return "imageSuccess";
	}

	private String confirmPwd;

	public String getConfirmPwd() {
		return confirmPwd;
	}

	public void setConfirmPwd(String confirmPwd) {
		this.confirmPwd = confirmPwd;
	}

	@Autowired
	private OaSysLogService oaSysLogService;

	public OaSysLogService getOaSysLogService() {
		return oaSysLogService;
	}

	public void setOaSysLogService(OaSysLogService oaSysLogService) {
		this.oaSysLogService = oaSysLogService;
	}

	public String about() {
		HttpServletRequest request = ServletActionContext.getRequest();

		String textC = request.getParameter("imageVerificationCode");

		HttpSession session = request.getSession();
		String textabout = (String) session.getAttribute("textabout");

		if (textabout != null && textC != null && textabout.toLowerCase().equals(textC.toLowerCase())) {

		} else {
			this.addFieldError("imageVerificationCode", "注册码不正确");
			return "aboutUI";
		}

		ValidateUtil validateBean = new ValidateUtil();
		if (validateBean.validateabout(oaSysUser, request.getParameter("confirmPwd")) == false) { // 如果校验失败
			for (Map.Entry<String, String> entry : validateBean.getErrors().entrySet()) {
				this.addFieldError(entry.getKey(), entry.getValue());
			}

			return "aboutUI";
		}

		// 获取用户填写的登录帐号
		String username = request.getParameter("username");
		OaSysUser oaSysUserFromdb = oaSysUserService.findByUsername(username);
		if (oaSysUserFromdb != null) {
			this.addActionError("注册帐号已存在");

			return "aboutUI";
		}

		String uuid = UUIDUtil.getUUID();

		oaSysUser.setCreatedUser(uuid);
		oaSysUser.setCreatedUserName(oaSysUser.getName());
		oaSysUser.setCreatedTime(DateUtil.currentTimeMillis());
		oaSysUser.setModifiedUser(uuid);
		oaSysUser.setModifiedUserName(oaSysUser.getName());
		oaSysUser.setModifiedTime(DateUtil.currentTimeMillis());
		oaSysUser.setIssys(DataUtil.admin);
		oaSysUser.setIsdel(DataUtil.adddata);
		oaSysUser.setStates(DataUtil.states0);

		oaSysUser.setPassword(MD5Util.encrypt1ToMD5(oaSysUser.getPassword()));

		oaSysUser.setUid(uuid);
		oaSysUser.setLicense(textC);
		oaSysUserService.save(oaSysUser);

		OaSysLog oaSysLog = new OaSysLog();
		oaSysLog.setLid(UUIDUtil.getUUID());
		oaSysLog.setDatatype(DataUtil.userdatatype);
		oaSysLog.setDataid(uuid);
		oaSysLog.setModifiedUser(uuid);
		oaSysLog.setModifiedUserName(oaSysUser.getName());
		oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
		oaSysLog.setRemarks("注册码 " + oaSysUser.toString());
		oaSysLogService.save(oaSysLog);

		session.setAttribute("aboutUser", "本产品授权给:" + oaSysUser.getName());

		return "aboutUI";
	}

	private String imageVerificationCode;

	public String getImageVerificationCode() {
		return imageVerificationCode;
	}

	public void setImageVerificationCode(String imageVerificationCode) {
		this.imageVerificationCode = imageVerificationCode;
	}
}
