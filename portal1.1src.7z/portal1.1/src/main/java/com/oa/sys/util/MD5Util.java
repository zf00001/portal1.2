package com.oa.sys.util;

import java.io.UnsupportedEncodingException;

/**
 * Created by zf on 2023年2月8日.
 */
public class MD5Util {

	/**
	 * MD5加密
	 * 
	 * @explain 借助apache工具类DigestUtils实现
	 * @param str 待加密字符串
	 * @return 16进制加密字符串
	 */
	public static String encrypt1ToMD5(String str) {
		return org.apache.commons.codec.digest.DigestUtils.md5Hex(str);
	}

	/**
	 * MD5加密
	 * 
	 * @explain springboot自带MD5加密
	 * @param str 待加密字符串
	 * @return 16进制加密字符串
	 */
	public static String encrypt2ToMD5(String str) {
		String md5 = "  ";
		try {
			md5 = org.springframework.util.DigestUtils.md5DigestAsHex(str.getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return md5;
	}

	public static void main(String[] args) {
	}

}
