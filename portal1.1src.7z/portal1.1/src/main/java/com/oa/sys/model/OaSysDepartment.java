package com.oa.sys.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * Created by zf on 2023年2月2日.
 */
@Entity
@Table(name = "oa_sys_department")
public class OaSysDepartment {
	@Id
	@GenericGenerator(name = "generator", strategy = "uuid.hex")
	@GeneratedValue(generator = "generator")
	@Column(name = "did", unique = true, nullable = false, length = 32)
	private String did;
	@Column(name = "number", length = 32)
	private String number;
	@Column(name = "name", length = 32)
	private String name;

	@Column(name = "isdel", length = 1)
	private String isdel;
	@Column(name = "createdUser", length = 32)
	private String createdUser;
	@Column(name = "createdUserName", length = 32)
	private String createdUserName;
	@Column(name = "createdTime", length = 32)
	private String createdTime;
	@Column(name = "modifiedUser", length = 32)
	private String modifiedUser;
	@Column(name = "modifiedUserName", length = 32)
	private String modifiedUserName;
	@Column(name = "modifiedTime", length = 32)
	private String modifiedTime;
	@Column(name = "states", length = 1)
	private String states;

	@Column(name = "remarks", length = 100)
	private String remarks;

	public String getDid() {
		return did;
	}

	public void setDid(String did) {
		this.did = did;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsdel() {
		return isdel;
	}

	public void setIsdel(String isdel) {
		this.isdel = isdel;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getCreatedUserName() {
		return createdUserName;
	}

	public void setCreatedUserName(String createdUserName) {
		this.createdUserName = createdUserName;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public String getModifiedUser() {
		return modifiedUser;
	}

	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	public String getModifiedUserName() {
		return modifiedUserName;
	}

	public void setModifiedUserName(String modifiedUserName) {
		this.modifiedUserName = modifiedUserName;
	}

	public String getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(String modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public String getStates() {
		return states;
	}

	public void setStates(String states) {
		this.states = states;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "OaSysDepartment [did=" + did + ", number=" + number + ", name=" + name + "]";
	}
}
