package com.oa.sys.util;

import java.util.UUID;

/**
 * Created by zf on 2023年2月10日.
 */
public class UUIDUtil {

	public static String getUUID() {
		String id = UUID.randomUUID().toString();
		String uuid = id.replaceAll("-", "");

		return uuid;
	}

	public static void main(String[] args) {
	}
}
