package com.oa.sys.service;

import java.util.List;

import com.oa.sys.model.OaSysDepartment;
import com.oa.sys.util.PageUtil;

/**
 * Created by zf on 2023年2月2日.
 */
public interface OaSysDepartmentService {
	PageUtil<OaSysDepartment> findByPage(Integer currPage);

	void save(OaSysDepartment oaSysDepartment);

	OaSysDepartment findById(String did);

	void update(OaSysDepartment oaSysDepartment);

	List<OaSysDepartment> findAll();
}
