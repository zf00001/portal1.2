
package com.oa.sys.web;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

import com.opensymphony.xwork2.ActionSupport;

@Namespace("/oa/sys/filedownload")
@Results({ @Result(name = "userdownloadSuccess", type = "stream", params = { "contentType",
		"application/octet-stream;charset=ISO8859-1", "bufferSize", "1024" }) })
public class FiledownloadAction extends ActionSupport {
	public String userdownload() {
		HttpServletResponse response = ServletActionContext.getResponse();

		String fileName = "用户管理.xls";
		String fileNameURL = "";
		try {
			fileNameURL = URLEncoder.encode(fileName, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		response.setHeader("Content-disposition",
				"attachment;filename=" + fileNameURL + ";" + "filename*=utf-8''" + fileNameURL);

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("\u7528\u6237\u7ba1\u7406");

		XSSFRow row = sheet.createRow(0);
		row.createCell(0).setCellValue("\u59d3\u540d");
		row.createCell(1).setCellValue("\u51fa\u751f\u5e74\u6708\u65e5");
		row.createCell(2).setCellValue("\u6027\u522b");
		row.createCell(3).setCellValue("\u804c\u52a1");
		row.createCell(4).setCellValue("\u90e8\u95e8");
		row.createCell(5).setCellValue("\u8054\u7cfb\u7535\u8bdd");
		row.createCell(6).setCellValue("E-mail");
		row.createCell(7).setCellValue("\u7f16\u53f7");
		row.createCell(8).setCellValue("\u5e10\u53f7");

		try {
			ServletOutputStream outputStream = response.getOutputStream();
			try {
				workbook.write(outputStream);
				outputStream.flush();
				outputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					outputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return "userdownloadSuccess";
	}

}
