package com.oa.sys.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.oa.sys.model.OaSysLog;
import com.oa.sys.model.OaSysRole;
import com.oa.sys.model.OaSysUser;
import com.oa.sys.service.OaSysLogService;
import com.oa.sys.service.OaSysRoleService;
import com.oa.sys.util.DataUtil;
import com.oa.sys.util.DateUtil;
import com.oa.sys.util.PageUtil;
import com.oa.sys.util.UUIDUtil;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

/**
 * Created by zf on 2023年2月2日.
 */
@Namespace("/oa/sys/role")
@Results({ @Result(name = "findAll", location = "list.jsp"), @Result(name = "addUI", location = "add.jsp"),
		@Result(name = "saveSuccess", type = "redirectAction", location = "role!findAll.do"),
		@Result(name = "editUI", location = "edit.jsp"),
		@Result(name = "updateSuccess", type = "redirectAction", location = "role!findAll.do"),
		@Result(name = "deleteSuccess", type = "redirectAction", location = "role!findAll.do")

})
public class RoleAction extends ActionSupport implements ModelDriven<OaSysRole> {
	private OaSysRole oaSysRole = new OaSysRole();

	@Override
	public OaSysRole getModel() {
		return oaSysRole;
	}

	private Integer currPage = 1;

	public void setCurrPage(Integer currPage) {
		this.currPage = currPage;
	}

	@Autowired
	private OaSysRoleService oaSysRoleService;

	public OaSysRoleService getOaSysRoleService() {
		return oaSysRoleService;
	}

	public void setOaSysRoleService(OaSysRoleService oaSysRoleService) {
		this.oaSysRoleService = oaSysRoleService;
	}

	@Autowired
	private OaSysLogService oaSysLogService;

	public OaSysLogService getOaSysLogService() {
		return oaSysLogService;
	}

	public void setOaSysLogService(OaSysLogService oaSysLogService) {
		this.oaSysLogService = oaSysLogService;
	}
	
	public String findAll() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "findAll";
		} else {
			PageUtil<OaSysRole> pageBean = oaSysRoleService.findByPage(currPage);
			ActionContext.getContext().getValueStack().push(pageBean);
		}
		return "findAll";
	}

	public String addUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "addUI";
		} else {
		}
		return "addUI";
	}

	public String save() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "saveSuccess";
		} else {
			oaSysRole.setCreatedUser(user.getUid());
			oaSysRole.setCreatedUserName(user.getName());
			oaSysRole.setCreatedTime(DateUtil.currentTimeMillis());
			oaSysRole.setModifiedUser(user.getUid());
			oaSysRole.setModifiedUserName(user.getName());
			oaSysRole.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysRole.setIsdel(DataUtil.adddata);
			oaSysRole.setStates(DataUtil.states0);

			String uuid =UUIDUtil.getUUID();
			oaSysRole.setRid(uuid);
			oaSysRoleService.save(oaSysRole);
			

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.roledatatype);
			oaSysLog.setDataid(uuid);
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedUserName(user.getName());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("职务添加 "+oaSysRole.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "saveSuccess";
	}

	public String editUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		
		if (user == null) {
			this.addActionError("请重新登录");
			return "addUI";
		} else {
			
			OaSysRole oaSysRoleFromdb = oaSysRoleService.findById(oaSysRole.getRid());
			
			ActionContext.getContext().getValueStack().push(oaSysRoleFromdb);
		}
		return "editUI";
	}

	public String update() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "updateSuccess";
		} else {
			OaSysRole oaSysRoleFromdb = oaSysRoleService.findById(oaSysRole.getRid());
			oaSysRoleFromdb.setNumber(oaSysRole.getNumber());
			oaSysRoleFromdb.setName(oaSysRole.getName());
			oaSysRoleFromdb.setRemarks(oaSysRole.getRemarks());

			oaSysRoleFromdb.setModifiedUser(user.getUid());
			oaSysRoleFromdb.setModifiedUserName(user.getName());
			oaSysRoleFromdb.setModifiedTime(DateUtil.currentTimeMillis());

			oaSysRoleService.update(oaSysRoleFromdb);
			

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.roledatatype);
			oaSysLog.setDataid(oaSysRole.getRid());
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedUserName(user.getName());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("职务编辑 "+oaSysRoleFromdb.toString());
			oaSysLogService.save(oaSysLog);
			
		}
		return "updateSuccess";
	}

	public String delete() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "deleteSuccess";
		} else {
			OaSysRole oaSysRoleFromdb = oaSysRoleService.findById(oaSysRole.getRid());
			oaSysRoleFromdb.setIsdel(DataUtil.deletedata);
			
			oaSysRoleFromdb.setModifiedUser(user.getUid());
			oaSysRoleFromdb.setModifiedUserName(user.getName());
			oaSysRoleFromdb.setModifiedTime(DateUtil.currentTimeMillis());

			oaSysRoleService.update(oaSysRoleFromdb);
			

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.roledatatype);
			oaSysLog.setDataid(oaSysRole.getRid());
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedUserName(user.getName());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("职务删除 "+oaSysRoleFromdb.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "deleteSuccess";
	}

}
