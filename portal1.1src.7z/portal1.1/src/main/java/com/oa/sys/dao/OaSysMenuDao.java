package com.oa.sys.dao;

import java.util.List;

import com.oa.sys.model.OaSysMenu;

/**
 * Created by zf on 2023年2月2日.
 */
public interface OaSysMenuDao {

	int findCount();

	List<OaSysMenu> findByPage(int begin, int pageSize);

	void save(OaSysMenu oaSysMenu);

	OaSysMenu findById(String mid);

	void update(OaSysMenu oaSysMenu);
}
