package com.oa.sys.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * Created by zf on 2023年2月2日.
 */
@Entity
@Table(name = "oa_sys_role_menu")
public class OaSysRoleMenu {
	@Id
	@GenericGenerator(name = "generator", strategy = "uuid.hex")
	@GeneratedValue(generator = "generator")
	@Column(name = "rmid", unique = true, nullable = false, length = 32)
	private String rmid;
	@Column(name = "rid", length = 32)
	private String rid;
	@Column(name = "mid", length = 32)
	private String mid;

	public String getRmid() {
		return rmid;
	}

	public void setRmid(String rmid) {
		this.rmid = rmid;
	}

	public String getRid() {
		return rid;
	}

	public void setRid(String rid) {
		this.rid = rid;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

}
