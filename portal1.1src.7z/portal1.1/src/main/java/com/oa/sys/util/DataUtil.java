package com.oa.sys.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by zf on 2023年2月11日.
 */
public class DataUtil {

	private static Map<String, String> onlineOaSysUser = new HashMap<String, String>();

	public static final String roledatatype = "1";
	public static final String departmentdatatype = "2";
	public static final String userdatatype = "3";
	public static final String menudatatype = "4";

	public static final String adddata = "0";
	public static final String deletedata = "1";

	public static final String states0 = "0";
	public static final String states1 = "1";
	public static final String states2 = "2";
	
	public static final String guest = "0";
	public static final String admin = "1";

	public static void saveOnlineOaSysUser(String uid, String sessionid) {
		onlineOaSysUser.put(uid, sessionid);
	}

	public static void deleteOnlineOaSysUser(String uid) {
		onlineOaSysUser.remove(uid);
	}

}
