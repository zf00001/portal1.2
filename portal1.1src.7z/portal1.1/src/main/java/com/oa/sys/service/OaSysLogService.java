package com.oa.sys.service;

import com.oa.sys.model.OaSysLog;
import com.oa.sys.util.PageUtil;

/**
 * Created by zf on 2023年2月4日.
 */
public interface OaSysLogService {

	PageUtil<OaSysLog> findByPage(Integer currPage, String optype, String opid);

	void save(OaSysLog oaSysLog);

	OaSysLog findById(String lid);
}
