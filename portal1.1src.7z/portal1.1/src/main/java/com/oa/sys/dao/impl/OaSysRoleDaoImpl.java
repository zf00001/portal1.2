package com.oa.sys.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.oa.sys.dao.OaSysRoleDao;
import com.oa.sys.model.OaSysRole;
import com.oa.sys.util.DataUtil;

/**
 * Created by zf on 2023年2月2日.
 */
@Repository
public class OaSysRoleDaoImpl extends HibernateDaoSupport implements OaSysRoleDao {

	@Override
	public int findCount() {
		String hql = "select count(*) from OaSysRole where isdel="+DataUtil.adddata+" ";
		List<?> list = this.getHibernateTemplate().find(hql);
		if (list.size() > 0) {
			return Integer.parseInt(list.get(0).toString());
		} else {
			return 0;
		}
	}

	@Override
	public List<OaSysRole> findByPage(int begin, int pageSize) {
		DetachedCriteria criteria = DetachedCriteria.forClass(OaSysRole.class);		
		criteria.add(Restrictions.eq("isdel", DataUtil.adddata));
		criteria.addOrder(Order.desc("rid"));

		List<OaSysRole> list = (List<OaSysRole>) this.getHibernateTemplate().findByCriteria(criteria, begin, pageSize);
		return list;
	}

	@Override
	public void save(OaSysRole oaSysRole) {
		this.getHibernateTemplate().save(oaSysRole);
	}

	@Override
	public OaSysRole findById(String rid) {
		OaSysRole oaSysRole = this.getHibernateTemplate().get(OaSysRole.class, rid);
		return oaSysRole;
	}

	@Override
	public void update(OaSysRole oaSysRole) {
		HibernateTemplate template = this.getHibernateTemplate();
		this.getHibernateTemplate().update(oaSysRole);
	}

	@Override
	public List<OaSysRole> findAll() {
		String hql = "from OaSysRole where isdel="+DataUtil.adddata+" ";
		List<OaSysRole> list = (List<OaSysRole>) this.getHibernateTemplate().find(hql);
		return list;
	}
}
