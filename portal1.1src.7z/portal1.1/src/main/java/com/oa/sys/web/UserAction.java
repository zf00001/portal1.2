package com.oa.sys.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.oa.sys.model.OaSysDepartment;
import com.oa.sys.model.OaSysLog;
import com.oa.sys.model.OaSysRole;
import com.oa.sys.model.OaSysUser;
import com.oa.sys.service.OaSysDepartmentService;
import com.oa.sys.service.OaSysLogService;
import com.oa.sys.service.OaSysRoleService;
import com.oa.sys.service.OaSysUserService;
import com.oa.sys.util.DataUtil;
import com.oa.sys.util.DateUtil;
import com.oa.sys.util.MD5Util;
import com.oa.sys.util.PageUtil;
import com.oa.sys.util.UUIDUtil;
import com.oa.sys.util.ValidateUtil;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

/**
 * Created by zf on 2023年2月2日.
 */
@Namespace("/oa/sys/user")
@Results({ @Result(name = "findAll", location = "list.jsp"), @Result(name = "addUI", location = "add.jsp"),
		@Result(name = "saveSuccess", type = "redirectAction", location = "user!findAll.do"),
		@Result(name = "editUI", location = "edit.jsp"),
		@Result(name = "updateSuccess", type = "redirectAction", location = "user!findAll.do"),
		@Result(name = "deleteSuccess", type = "redirectAction", location = "user!findAll.do"),
		@Result(name = "loginUI", location = "login.jsp"), @Result(name = "loginSuccess", location = "welcome.jsp"),
		@Result(name = "logoutSuccess", location = "welcome.jsp"), @Result(name = "registUI", location = "regist.jsp"),
		@Result(name = "registSuccess", location = "welcome.jsp") })
public class UserAction extends ActionSupport implements ModelDriven<OaSysUser> {
	private OaSysUser oaSysUser = new OaSysUser();

	@Override
	public OaSysUser getModel() {
		return oaSysUser;
	}

	private Integer currPage = 1;

	public void setCurrPage(Integer currPage) {
		this.currPage = currPage;
	}

	@Autowired
	private OaSysUserService oaSysUserService;

	public OaSysUserService getOaSysUserService() {
		return oaSysUserService;
	}

	public void setOaSysUserService(OaSysUserService oaSysUserService) {
		this.oaSysUserService = oaSysUserService;
	}

	@Autowired
	private OaSysDepartmentService oaSysDepartmentService;

	public OaSysDepartmentService getOaSysDepartmentService() {
		return oaSysDepartmentService;
	}

	@Autowired
	private OaSysLogService oaSysLogService;

	public OaSysLogService getOaSysLogService() {
		return oaSysLogService;
	}

	public void setOaSysLogService(OaSysLogService oaSysLogService) {
		this.oaSysLogService = oaSysLogService;
	}

	public void setOaSysDepartmentService(OaSysDepartmentService oaSysDepartmentService) {
		this.oaSysDepartmentService = oaSysDepartmentService;
	}

	@Autowired
	private OaSysRoleService oaSysRoleService;

	public OaSysRoleService getOaSysRoleService() {
		return oaSysRoleService;
	}

	public void setOaSysRoleService(OaSysRoleService oaSysRoleService) {
		this.oaSysRoleService = oaSysRoleService;
	}

	public String findAll() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "findAll";
		} else {
			PageUtil<OaSysUser> pageBean = oaSysUserService.findByPage(currPage);
			ActionContext.getContext().getValueStack().push(pageBean);
		}
		return "findAll";
	}

	public String addUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			ActionContext.getContext().getValueStack().set("departmentlist", new ArrayList<OaSysDepartment>());
			ActionContext.getContext().getValueStack().set("rolelist", new ArrayList<OaSysRole>());
			return "addUI";
		} else {
			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
		}
		return "addUI";
	}

	public String save() {
		HttpServletRequest request = ServletActionContext.getRequest();

		ValidateUtil validateBean = new ValidateUtil();
		if (validateBean.validateOaSysUser(oaSysUser, request.getParameter("confirmPwd")) == false) { // 如果校验失败
			for (Map.Entry<String, String> entry : validateBean.getErrors().entrySet()) {
				this.addFieldError(entry.getKey(), entry.getValue());
			}

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "addUI";
		}

		// 获取用户填写的登录帐号
		String username = request.getParameter("username");
		OaSysUser oaSysUserFromdb = oaSysUserService.findByUsername(username);
		if (oaSysUserFromdb != null) {
			this.addActionError("注册帐号已存在");

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "addUI";
		}

		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "saveSuccess";
		} else {

			oaSysUser.setCreatedUser(user.getUid());
			oaSysUser.setCreatedUserName(user.getName());
			oaSysUser.setCreatedTime(DateUtil.currentTimeMillis());
			oaSysUser.setModifiedUser(user.getUid());
			oaSysUser.setModifiedUserName(user.getName());
			oaSysUser.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysUser.setIssys(DataUtil.guest);
			oaSysUser.setIsdel(DataUtil.adddata);
			oaSysUser.setStates(DataUtil.states0);

			oaSysUser.setPassword(MD5Util.encrypt1ToMD5(oaSysUser.getPassword()));

			String uuid = UUIDUtil.getUUID();
			oaSysUser.setUid(uuid);
			oaSysUserService.save(oaSysUser);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.userdatatype);
			oaSysLog.setDataid(uuid);
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedUserName(user.getName());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户添加 " + oaSysUser.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "saveSuccess";
	}

	public String editUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			ActionContext.getContext().getValueStack().set("departmentlist", new ArrayList<OaSysDepartment>());
			ActionContext.getContext().getValueStack().set("rolelist", new ArrayList<OaSysRole>());
			return "editUI";
		} else {
			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);

			OaSysUser oaSysUserFromdb = oaSysUserService.findById(oaSysUser.getUid());
			oaSysUserFromdb.setPassword("");
			ActionContext.getContext().getValueStack().push(oaSysUserFromdb);
		}
		return "editUI";
	}

	public String update() {
		HttpServletRequest request = ServletActionContext.getRequest();

		ValidateUtil validateBean = new ValidateUtil();
		if (validateBean.validateOaSysUser(oaSysUser, request.getParameter("confirmPwd")) == false) { // 如果校验失败
			for (Map.Entry<String, String> entry : validateBean.getErrors().entrySet()) {
				this.addFieldError(entry.getKey(), entry.getValue());
			}

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "editUI";
		}

		// 获取用户填写的登录帐号
		String username = request.getParameter("username");
		OaSysUser oaSysUserFromdbForUpdate = oaSysUserService.findByUsernameForUpdate(oaSysUser.getUid(), username);
		if (oaSysUserFromdbForUpdate != null) {
			this.addActionError("注册帐号已存在");

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "editUI";
		}

		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "updateSuccess";
		} else {
			OaSysUser oaSysUserFromdb = oaSysUserService.findById(oaSysUser.getUid());
			// 修改基本信息
			oaSysUserFromdb.setNumber(oaSysUser.getNumber());
			oaSysUserFromdb.setName(oaSysUser.getName());
			oaSysUserFromdb.setUsername(oaSysUser.getUsername());
			oaSysUserFromdb.setPassword(MD5Util.encrypt1ToMD5(oaSysUser.getPassword()));
			oaSysUserFromdb.setEmail(oaSysUser.getEmail());
			oaSysUserFromdb.setPhone(oaSysUser.getPhone());
			oaSysUserFromdb.setBirthday(oaSysUser.getBirthday());
			oaSysUserFromdb.setGender(oaSysUser.getGender());
			oaSysUserFromdb.setDid(oaSysUser.getDid());
			oaSysUserFromdb.setDname(oaSysUser.getDname());
			oaSysUserFromdb.setRid(oaSysUser.getRid());
			oaSysUserFromdb.setRname(oaSysUser.getRname());

			oaSysUserFromdb.setModifiedUser(user.getUid());
			oaSysUserFromdb.setModifiedUserName(user.getName());
			oaSysUserFromdb.setModifiedTime(DateUtil.currentTimeMillis());

			oaSysUserService.update(oaSysUserFromdb);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.userdatatype);
			oaSysLog.setDataid(oaSysUser.getUid());
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedUserName(user.getName());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户编辑 " + oaSysUserFromdb.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "updateSuccess";
	}

	public String delete() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			this.addActionError("请重新登录");
			return "deleteSuccess";
		} else {
			OaSysUser oaSysUserFromdb = oaSysUserService.findById(oaSysUser.getUid());
			oaSysUserFromdb.setIsdel(DataUtil.deletedata);

			oaSysUserFromdb.setModifiedUser(user.getUid());
			oaSysUserFromdb.setModifiedUserName(user.getName());
			oaSysUserFromdb.setModifiedTime(DateUtil.currentTimeMillis());

			oaSysUserService.update(oaSysUserFromdb);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.userdatatype);
			oaSysLog.setDataid(oaSysUser.getUid());
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedUserName(user.getName());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户删除 " + oaSysUserFromdb.toString());
			oaSysLogService.save(oaSysLog);
		}
		return "deleteSuccess";
	}

	public String loginUI() {
		return "loginUI";
	}

	private String imageVerificationCode;

	public String getImageVerificationCode() {
		return imageVerificationCode;
	}

	public void setImageVerificationCode(String imageVerificationCode) {
		this.imageVerificationCode = imageVerificationCode;
	}

	public String login() {
		HttpServletRequest request = ServletActionContext.getRequest();

		// 获取用户填写的登录帐号
		String username = request.getParameter("username");
		// 获取用户填写的登录密码
		String password = request.getParameter("password");

		String textC = request.getParameter("imageVerificationCode");

		HttpSession session = request.getSession();
		String textaimage = (String) session.getAttribute("textaimage");

		if (textaimage != null && textC != null && textaimage.toLowerCase().equals(textC.toLowerCase())) {

		} else {
			this.addFieldError("imageVerificationCode", "验证码不正确");
			return "loginUI";
		}

		ValidateUtil validateBean = new ValidateUtil();
		if (validateBean.validateLoin(oaSysUser) == false) { // 如果校验失败
			for (Map.Entry<String, String> entry : validateBean.getErrors().entrySet()) {
				this.addFieldError(entry.getKey(), entry.getValue());
			}

			return "loginUI";
		}

		OaSysUser oaSysUserFromdb = oaSysUserService.findByUsernameAndPassword(username,
				MD5Util.encrypt1ToMD5(password));

		if (oaSysUserFromdb == null) {
			this.addActionError("帐号或者密码错误");
			return "loginUI";
		} else {
			// 登录成功后，就将用户存储到session中

			OaSysUser onlineOaSysUser = new OaSysUser();
			onlineOaSysUser.setUid(oaSysUserFromdb.getUid());
			onlineOaSysUser.setName(oaSysUserFromdb.getName());
			onlineOaSysUser.setUsername(username);
			onlineOaSysUser.setPassword(password);

			oaSysUserService.saveOnlineOaSysUser("" + onlineOaSysUser.getUid(), "" + session.getId());

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.userdatatype);
			oaSysLog.setDataid("");
			oaSysLog.setModifiedUser(oaSysUserFromdb.getUid());
			oaSysLog.setModifiedUserName(oaSysUserFromdb.getName());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户登录 ");
			oaSysLogService.save(oaSysLog);

			session.setAttribute("user", onlineOaSysUser);

			return "loginSuccess";
		}
	}

	public String logout() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();

		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user != null) {
			oaSysUserService.deleteOnlineOaSysUser("" + user.getUid());

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.userdatatype);
			oaSysLog.setDataid("");
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedUserName(user.getName());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("退出登陆 ");
			oaSysLogService.save(oaSysLog);

			// 移除存储在session中的user对象，实现注销功能
			session.removeAttribute("user");
		}
		// 销毁session
		session.invalidate();

		return "logoutSuccess";
	}

	public String registUI() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);

			return "registUI";
		} else {
			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
		}
		return "registUI";
	}

	private String confirmPwd;

	public String getConfirmPwd() {
		return confirmPwd;
	}

	public void setConfirmPwd(String confirmPwd) {
		this.confirmPwd = confirmPwd;
	}

	public String regist() {
		HttpServletRequest request = ServletActionContext.getRequest();

		ValidateUtil validateBean = new ValidateUtil();
		if (validateBean.validateOaSysUser(oaSysUser, request.getParameter("confirmPwd")) == false) { // 如果校验失败
			for (Map.Entry<String, String> entry : validateBean.getErrors().entrySet()) {
				this.addFieldError(entry.getKey(), entry.getValue());
			}

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "registUI";
		}

		// 获取用户填写的登录帐号
		String username = request.getParameter("username");
		OaSysUser oaSysUserFromdb = oaSysUserService.findByUsername(username);
		if (oaSysUserFromdb != null) {
			this.addActionError("注册帐号已存在");

			List<OaSysDepartment> departmentlist = oaSysDepartmentService.findAll();
			ActionContext.getContext().getValueStack().set("departmentlist", departmentlist);

			List<OaSysRole> rolelist = oaSysRoleService.findAll();
			ActionContext.getContext().getValueStack().set("rolelist", rolelist);
			return "registUI";
		}

		HttpSession session = request.getSession();
		OaSysUser user = (OaSysUser) session.getAttribute("user");
		if (user == null) {
			String uuid = UUIDUtil.getUUID();

			oaSysUser.setCreatedUser(uuid);
			oaSysUser.setCreatedUserName(oaSysUser.getName());
			oaSysUser.setCreatedTime(DateUtil.currentTimeMillis());
			oaSysUser.setModifiedUser(uuid);
			oaSysUser.setModifiedUserName(oaSysUser.getName());
			oaSysUser.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysUser.setIssys(DataUtil.guest);
			oaSysUser.setIsdel(DataUtil.adddata);
			oaSysUser.setStates(DataUtil.states0);

			oaSysUser.setPassword(MD5Util.encrypt1ToMD5(oaSysUser.getPassword()));

			oaSysUser.setUid(uuid);
			oaSysUserService.save(oaSysUser);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.userdatatype);
			oaSysLog.setDataid(uuid);
			oaSysLog.setModifiedUser(uuid);
			oaSysLog.setModifiedUserName(oaSysUser.getName());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户注册 " + oaSysUser.toString());
			oaSysLogService.save(oaSysLog);

			this.addActionMessage("注册成功");
			return "registSuccess";
		} else {

			oaSysUser.setCreatedUser(user.getUid());
			oaSysUser.setCreatedUserName(user.getName());
			oaSysUser.setCreatedTime(DateUtil.currentTimeMillis());
			oaSysUser.setModifiedUser(user.getUid());
			oaSysUser.setModifiedUserName(user.getName());
			oaSysUser.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysUser.setIssys(DataUtil.guest);
			oaSysUser.setIsdel(DataUtil.adddata);
			oaSysUser.setStates(DataUtil.states0);

			oaSysUser.setPassword(MD5Util.encrypt1ToMD5(oaSysUser.getPassword()));

			String uuid = UUIDUtil.getUUID();
			oaSysUser.setUid(uuid);
			oaSysUserService.save(oaSysUser);

			OaSysLog oaSysLog = new OaSysLog();
			oaSysLog.setLid(UUIDUtil.getUUID());
			oaSysLog.setDatatype(DataUtil.userdatatype);
			oaSysLog.setDataid(uuid);
			oaSysLog.setModifiedUser(user.getUid());
			oaSysLog.setModifiedUserName(user.getName());
			oaSysLog.setModifiedTime(DateUtil.currentTimeMillis());
			oaSysLog.setRemarks("用户注册 " + oaSysUser.toString());
			oaSysLogService.save(oaSysLog);

			this.addActionMessage("注册成功");
		}
		return "registSuccess";
	}

}
