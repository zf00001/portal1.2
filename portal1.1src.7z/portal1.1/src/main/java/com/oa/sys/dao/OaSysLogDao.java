package com.oa.sys.dao;

import java.util.List;

import com.oa.sys.model.OaSysLog;

/**
 * Created by zf on 2023年2月2日.
 */
public interface OaSysLogDao {

	int findCount(String optype, String opid);

	List<OaSysLog> findByPage(int begin, int pageSize, String optype, String opid);

	void save(OaSysLog oaSysLog);

	OaSysLog findById(String lid);
}
