package com.oa.sys.util;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.oa.sys.model.OaSysUser;

/**
 * Created by zf on 2023年2月2日.
 */
public class ValidateUtil {

	private Map<String, String> errors = new HashMap<String, String>();

	public Map<String, String> getErrors() {
		return errors;
	}

	public void setErrors(Map<String, String> errors) {
		this.errors = errors;
	}

	public boolean validateabout(OaSysUser oaSysUser, String confirmPwd) {
		boolean isOk = true;

		String name = oaSysUser.getName();
		if (name == null || name.trim().equals("")) {
			isOk = false;
			errors.put("name", "姓名不能为空");
		}

		String username = oaSysUser.getUsername();
		if (username == null || username.trim().equals("")) {
			isOk = false;
			errors.put("username", "帐号不能为空");
		} else {
			if (!regexMatchesUsername(username)) {
				isOk = false;
				errors.put("username", "帐号不正确,帐号是否合法(字母开头，允许5-16字节，允许字母数字下划线)");
			}
		}
		String password = oaSysUser.getPassword();
		if (password == null || password.trim().equals("")) {
			isOk = false;
			errors.put("password", "密码不能为空");
		} else {
			if (!regexMatchesUsername(password)) {
				isOk = false;
				errors.put("password", "密码不正确,强密码(必须包含大小写字母和数字的组合，可以使用特殊字符，长度在8-10之间)");
			}
		}

		if (confirmPwd != null) {
			if (!confirmPwd.equals(password)) {
				isOk = false;
				errors.put("confirmPwd", "两次密码不一致");
			}
		}

		return isOk;
	}

	public boolean validateOaSysUser(OaSysUser oaSysUser, String confirmPwd) {
		boolean isOk = true;

		String birthday = oaSysUser.getBirthday();
		if (birthday != null && !birthday.trim().equals("")) {
			if (!regexMatchesDate(birthday)) {
				isOk = false;
				errors.put("birthday", "出生年月日不正确");
			}
		}

		if (oaSysUser.getRid().trim().equals("")) {
			isOk = false;
			errors.put("rid", "职务不能为空");
		}

		if (oaSysUser.getDid().trim().equals("")) {
			isOk = false;
			errors.put("did", "部门不能为空");
		}

		String email = oaSysUser.getEmail();
		if (email != null && !email.trim().equals("")) {
			if (!regexMatchesEmail(email)) {
				isOk = false;
				errors.put("email", "E-mail不正确");
			}
		}
		String username = oaSysUser.getUsername();
		if (username == null || username.trim().equals("")) {
			isOk = false;
			errors.put("username", "帐号不能为空");
		} else {
			if (!regexMatchesUsername(username)) {
				isOk = false;
				errors.put("username", "帐号不正确,帐号是否合法(字母开头，允许5-16字节，允许字母数字下划线)");
			}
		}
		String password = oaSysUser.getPassword();
		if (password == null || password.trim().equals("")) {
			isOk = false;
			errors.put("password", "密码不能为空");
		} else {
			if (!regexMatchesUsername(password)) {
				isOk = false;
				errors.put("password", "密码不正确,强密码(必须包含大小写字母和数字的组合，可以使用特殊字符，长度在8-10之间)");
			}
		}

		if (confirmPwd != null) {
			if (!confirmPwd.equals(password)) {
				isOk = false;
				errors.put("confirmPwd", "两次密码不一致");
			}
		}

		return isOk;
	}

	public boolean validateLoin(OaSysUser oaSysUser) {
		boolean isOk = true;

		String username = oaSysUser.getUsername();
		if (username == null || username.trim().equals("")) {
			isOk = false;
			errors.put("username", "帐号不能为空");
		} else {
			if (!regexMatchesUsername(username)) {
				isOk = false;
				errors.put("username", "帐号不正确,帐号是否合法(字母开头，允许5-16字节，允许字母数字下划线)");
			}
		}
		String password = oaSysUser.getPassword();
		if (password == null || password.trim().equals("")) {
			isOk = false;
			errors.put("password", "密码不能为空");
		} else {
			if (!regexMatchesUsername(password)) {
				isOk = false;
				errors.put("password", "密码不正确,强密码(必须包含大小写字母和数字的组合，可以使用特殊字符，长度在8-10之间)");
			}
		}

		return isOk;
	}

	// Email地址
	public static boolean regexMatchesEmail(String str) {
		String pattern = "\\w[-\\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\\.)+[A-Za-z]{2,14}";
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(str);

		return m.matches();
	}

	// 帐号是否合法(字母开头，允许5-16字节，允许字母数字下划线)：^[a-zA-Z][a-zA-Z0-9_]{4,15}$
	public static boolean regexMatchesUsername(String str) {
		String pattern = "[a-zA-Z][a-zA-Z0-9_]{4,15}";
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(str);
		return m.matches();

	}

	// 密码(以字母开头，长度在6~18之间，只能包含字母、数字和下划线)：^[a-zA-Z]\w{5,17}$
	// 强密码(必须包含大小写字母和数字的组合，不能使用特殊字符，长度在 8-10
	// 之间)：^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9]{8,10}$
	// 强密码(必须包含大小写字母和数字的组合，可以使用特殊字符，长度在8-10之间)：^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,10}$
	public static boolean regexMatchesPassword(String str) {
		String pattern = "(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,10}";
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(str);
		return m.matches();

	}

	// 格式日期
	public static boolean regexMatchesDate(String str) {
		String pattern = "\\d{4}(\\-|\\/|.)\\d{1,2}\\1\\d{1,2}";

		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(str);

		return m.matches();
	}

	// 手机（国内）
	public static boolean regexMatchesPhone(String str) {
		String pattern = "0?(13|14|15|17|18)[0-9]{9}";

		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(str);

		return m.matches();
	}

	public static void main(String[] args) {

	}
}
