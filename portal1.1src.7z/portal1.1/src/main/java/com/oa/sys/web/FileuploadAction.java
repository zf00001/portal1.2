
package com.oa.sys.web;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

import com.opensymphony.xwork2.ActionSupport;

@Namespace("/oa/sys/fileupload")
@Results({ @Result(name = "useruploadUI", location = "upload.jsp"),
		@Result(name = "useruploadSuccess", location = "success.jsp") })
public class FileuploadAction extends ActionSupport {

	private List<File> uploads = new ArrayList<>();
	private List<String> uploadFileNames = new ArrayList<>();
	private List<String> uploadContentTypes = new ArrayList<>();

	public List<File> getUpload() {
		return this.uploads;
	}

	public void setUpload(List<File> uploads) {
		this.uploads = uploads;
	}

	public List<String> getUploadFileName() {
		return this.uploadFileNames;
	}

	public void setUploadFileName(List<String> uploadFileNames) {
		this.uploadFileNames = uploadFileNames;
	}

	public List<String> getUploadContentType() {
		return this.uploadContentTypes;
	}

	public void setUploadContentType(List<String> contentTypes) {
		this.uploadContentTypes = contentTypes;
	}

	public String useruploadUI() throws Exception {
		return "useruploadUI";
	}

	public String userupload() {
		try {
			for (int i = 0; i < uploads.size(); i++) {
				File uploadFile = uploads.get(i);

				XSSFWorkbook workbook = new XSSFWorkbook(uploadFile);
				XSSFSheet sheet = workbook.getSheetAt(0);
				for (Row row : sheet) {
					for (Cell cell : row) {
						String value = cell.getStringCellValue();
						System.out.print(value + " ");

					}
					System.out.println("");
				}
				workbook.close();
			}
			this.addActionMessage("导入成功");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "useruploadSuccess";
	}

}
